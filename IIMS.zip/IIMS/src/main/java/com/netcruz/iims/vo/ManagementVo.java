package com.netcruz.iims.vo;

public class ManagementVo {
	private int id;
	private String category;
	private String date;
	private String equipment;
	private String title;
	private String contents;
	private String note;
	private String period_type;
	private String company;
	private String user_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getEquipment() {
		return equipment;
	}
	public void setEquipment(String equipment) {
		this.equipment = equipment;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getPeriod_type() {
		return period_type;
	}
	public void setPeriod_type(String period_type) {
		this.period_type = period_type;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	@Override
	public String toString() {
		return "ManagementVo [id=" + id + ", category=" + category + ", date="
				+ date + ", equipment=" + equipment + ", title=" + title
				+ ", contents=" + contents + ", note=" + note
				+ ", period_type=" + period_type + ", company=" + company
				+ ", user_id=" + user_id + "]";
	}
	
	
	
}
